#include <iostream>
#include <string>
#include <cstdlib>
#include <cmath>

using namespace std;

long long IntegerPartToDecimal(string integerStr, int base);
double FractionalPartToDecimal(string fractionalStr, int base);
string DecimalToBase(long long integerPartDecimal, double fractionalPartDecimal, int base);

int main() {
    string input;

    cout << "���_��BOH�i���ഫ�t�� 1.1" << endl;
    while (true) {
        cout << "�п�J�ثe�i��(2/8/10/16)���Uq�h�h�X: ";
        cin >> input;

        if (input == "q") {
            break;
        }

        int currentBase = atoi(input.c_str());

        if (currentBase != 2 && currentBase != 8 && currentBase != 10 && currentBase != 16) {
            cout << "��J���~!���s�ӹL\n";
            continue;
        }

        cout << "��J�ഫ�ƭ�: ";
        cin >> input;

        
        size_t pointPosition = input.find('.');
        string integerPart, fractionalPart;
        if (pointPosition != string::npos) {
            integerPart = input.substr(0, pointPosition);
            fractionalPart = input.substr(pointPosition + 1);
        }
        else {
            integerPart = input;
        }

        long long integerPartDecimal = IntegerPartToDecimal(integerPart, currentBase);
        double fractionalPartDecimal = 0.0;
        if (!fractionalPart.empty()) {
            fractionalPartDecimal = FractionalPartToDecimal(fractionalPart, currentBase);
        }

        cout << "��J�ഫ�i��(2/8/10/16): ";
        cin >> input;

        int targetBase = atoi(input.c_str());

        if (targetBase != 2 && targetBase != 8 && targetBase != 10 && targetBase != 16) {
            cout << "��J���~!���s�ӹL\n";
            continue;
        }

        string result = DecimalToBase(integerPartDecimal, fractionalPartDecimal, targetBase);

        cout << "���G:" << result << "\n";
    }

    return 0;
}

long long IntegerPartToDecimal(string integerStr, int base) {
    long long decimalValue = 0;

    for (int i = integerStr.length() - 1; i >= 0; i--) {
        char digit = integerStr[i];
        int digitValue = isdigit(digit) ? digit - '0' : toupper(digit) - 'A' + 10;
        decimalValue += digitValue * pow(base, integerStr.length() - 1 - i);
    }

    return decimalValue;
}

double FractionalPartToDecimal(string fractionalStr, int base) {
    double decimalValue = 0.0;

    for (size_t i = 0; i < fractionalStr.length(); i++) {
        char digit = fractionalStr[i];
        int digitValue = isdigit(digit) ? digit - '0' : toupper(digit) - 'A' + 10;
        decimalValue += digitValue / pow(base, i + 1);
    }

    return decimalValue;
}

string DecimalToBase(long long integerPartDecimal, double fractionalPartDecimal, int base) {
    string result = "";

    while (integerPartDecimal > 0) {
        int remainder = integerPartDecimal % base;
        char digit = (remainder < 10) ? ('0' + remainder) : ('A' + remainder - 10);
        result = digit + result;
        integerPartDecimal /= base;
    }

    if (result.empty()) {
        result = "0";
    }

    if (fractionalPartDecimal > 0.0) {
        result += ".";

        for (int i = 0; i < 10; i++) {
            fractionalPartDecimal *= base;
            int digit = static_cast<int>(fractionalPartDecimal);
            char digitChar = (digit < 10) ? ('0' + digit) : ('A' + digit - 10);
            result += digitChar;
            fractionalPartDecimal -= digit;

            if (fractionalPartDecimal == 0.0) {
                break;
            }
        }
    }

    return result;
}
